import { useState } from 'react';
import { motion } from 'motion/react';
import { Sparkles, LogIn, UserPlus } from 'lucide-react';
import { createClient } from '../utils/supabase/client';
import { storage } from '../utils/storage';
import { projectId, publicAnonKey } from '../utils/supabase/info';

interface LoginProps {
  onLogin: (accessToken: string, userProfile: { name: string; email: string }) => void;
}

export const Login = ({ onLogin }: LoginProps) => {
  const [mode, setMode] = useState<'login' | 'signup' | 'guest'>('guest');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [guestName, setGuestName] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleGuestLogin = () => {
    if (!guestName.trim()) {
      setError('Please enter your name');
      return;
    }

    storage.saveUserProfile({ name: guestName.trim() });
    onLogin('', { name: guestName.trim(), email: '' });
  };

  const handleSignup = async () => {
    if (!email || !password || !name) {
      setError('All fields are required');
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-290939a6/signup`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${publicAnonKey}`,
          },
          body: JSON.stringify({ email, password, name }),
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Signup failed');
      }

      // After signup, automatically sign in
      const supabase = createClient();
      const { data: sessionData, error: signInError } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (signInError) throw signInError;

      const userProfile = { name, email };
      storage.saveUserProfile(userProfile);
      onLogin(sessionData.session?.access_token || '', userProfile);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Signup failed');
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogin = async () => {
    if (!email || !password) {
      setError('Email and password are required');
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      const supabase = createClient();
      const { data, error: signInError } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (signInError) throw signInError;

      const userProfile = {
        name: data.user?.user_metadata?.name || email.split('@')[0],
        email,
      };
      storage.saveUserProfile(userProfile);
      onLogin(data.session?.access_token || '', userProfile);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Login failed');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-indigo-900 to-emerald-800 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md"
      >
        {/* Logo */}
        <div className="text-center mb-8">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: 'spring', stiffness: 200 }}
            className="w-20 h-20 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 flex items-center justify-center shadow-2xl shadow-indigo-500/50"
          >
            <Sparkles className="w-10 h-10 text-white" />
          </motion.div>
          <h1 className="text-white/90 mb-2">AI Chatbot</h1>
          <p className="text-white/60">Your intelligent conversation partner</p>
        </div>

        {/* Form */}
        <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl p-6 shadow-2xl">
          {/* Mode tabs */}
          <div className="flex gap-2 mb-6 bg-white/5 p-1 rounded-xl">
            {(['guest', 'login', 'signup'] as const).map((m) => (
              <button
                key={m}
                onClick={() => {
                  setMode(m);
                  setError('');
                }}
                className={`flex-1 py-2 px-4 rounded-lg transition-all capitalize ${
                  mode === m
                    ? 'bg-gradient-to-r from-indigo-500 to-purple-500 text-white'
                    : 'text-white/60 hover:text-white/90'
                }`}
              >
                {m}
              </button>
            ))}
          </div>

          {error && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-4 p-3 bg-red-500/20 border border-red-400/30 rounded-lg text-red-200 text-sm"
            >
              {error}
            </motion.div>
          )}

          {mode === 'guest' ? (
            <div className="space-y-4">
              <div>
                <label className="block text-white/80 mb-2">Your Name</label>
                <input
                  type="text"
                  value={guestName}
                  onChange={(e) => setGuestName(e.target.value)}
                  placeholder="Enter your name"
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-white/40 outline-none focus:border-indigo-400 transition-colors"
                  onKeyPress={(e) => e.key === 'Enter' && handleGuestLogin()}
                />
              </div>
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={handleGuestLogin}
                className="w-full py-3 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-xl text-white flex items-center justify-center gap-2 hover:shadow-lg hover:shadow-indigo-500/50 transition-all"
              >
                <UserPlus className="w-5 h-5" />
                Continue as Guest
              </motion.button>
            </div>
          ) : (
            <div className="space-y-4">
              {mode === 'signup' && (
                <div>
                  <label className="block text-white/80 mb-2">Name</label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Your name"
                    className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-white/40 outline-none focus:border-indigo-400 transition-colors"
                  />
                </div>
              )}
              <div>
                <label className="block text-white/80 mb-2">Email</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-white/40 outline-none focus:border-indigo-400 transition-colors"
                />
              </div>
              <div>
                <label className="block text-white/80 mb-2">Password</label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-white/40 outline-none focus:border-indigo-400 transition-colors"
                  onKeyPress={(e) => e.key === 'Enter' && (mode === 'login' ? handleLogin() : handleSignup())}
                />
              </div>
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={mode === 'login' ? handleLogin : handleSignup}
                disabled={isLoading}
                className="w-full py-3 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-xl text-white flex items-center justify-center gap-2 hover:shadow-lg hover:shadow-indigo-500/50 transition-all disabled:opacity-50"
              >
                <LogIn className="w-5 h-5" />
                {isLoading ? 'Please wait...' : mode === 'login' ? 'Sign In' : 'Create Account'}
              </motion.button>
            </div>
          )}

          <p className="text-xs text-white/40 text-center mt-4">
            Note: This is a demo app. For production use, ensure proper security measures.
          </p>
        </div>
      </motion.div>
    </div>
  );
};
