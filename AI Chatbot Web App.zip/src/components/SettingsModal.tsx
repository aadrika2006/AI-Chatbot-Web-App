import { motion, AnimatePresence } from 'motion/react';
import { X, Cpu } from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedModel: string;
  onModelChange: (model: string) => void;
}

const models = [
  { id: 'gpt-3.5-turbo', name: 'GPT-3.5 Turbo', description: 'Fast and efficient' },
  { id: 'gpt-4', name: 'GPT-4', description: 'Most capable model' },
  { id: 'gpt-4-turbo-preview', name: 'GPT-4 Turbo', description: 'Enhanced performance' },
];

export const SettingsModal = ({ isOpen, onClose, selectedModel, onModelChange }: SettingsModalProps) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50"
          />

          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4"
          >
            <div className="bg-gradient-to-br from-slate-800/90 to-slate-900/90 backdrop-blur-xl border border-white/10 rounded-2xl max-w-md w-full p-6 shadow-2xl">
              {/* Header */}
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-white/90 flex items-center gap-2">
                  <Cpu className="w-5 h-5" />
                  Settings
                </h2>
                <button
                  onClick={onClose}
                  className="p-2 hover:bg-white/10 rounded-lg transition-colors"
                  aria-label="Close"
                >
                  <X className="w-5 h-5 text-white/70" />
                </button>
              </div>

              {/* Model selection */}
              <div>
                <h3 className="text-white/80 mb-3">AI Model</h3>
                <div className="space-y-2">
                  {models.map(model => (
                    <motion.button
                      key={model.id}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => onModelChange(model.id)}
                      className={`w-full text-left p-4 rounded-xl transition-all ${
                        selectedModel === model.id
                          ? 'bg-gradient-to-r from-indigo-500/20 to-purple-500/20 border-2 border-indigo-400/50'
                          : 'bg-white/5 border border-white/10 hover:bg-white/10'
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <p className="text-white/90">{model.name}</p>
                          <p className="text-sm text-white/50 mt-1">{model.description}</p>
                        </div>
                        {selectedModel === model.id && (
                          <div className="w-5 h-5 rounded-full bg-indigo-500 flex items-center justify-center">
                            <div className="w-2 h-2 rounded-full bg-white" />
                          </div>
                        )}
                      </div>
                    </motion.button>
                  ))}
                </div>
              </div>

              {/* Info */}
              <div className="mt-6 p-4 bg-blue-500/10 border border-blue-400/20 rounded-lg">
                <p className="text-sm text-blue-200/70">
                  Note: Different models have varying capabilities and response times. GPT-4 provides more accurate and detailed responses.
                </p>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};
