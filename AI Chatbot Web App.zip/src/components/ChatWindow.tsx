import { useState, useRef, useEffect } from 'react';
import { motion } from 'motion/react';
import { Send, Menu, Trash2 } from 'lucide-react';
import { MessageBubble } from './MessageBubble';
import { TypingIndicator } from './TypingIndicator';
import { Message, ChatThread } from '../utils/storage';
import { projectId, publicAnonKey } from '../utils/supabase/info';

interface ChatWindowProps {
  activeThread: ChatThread | null;
  onMessagesUpdate: (messages: Message[]) => void;
  onSidebarToggle: () => void;
  onClearChat: () => void;
  selectedModel: string;
  accessToken?: string;
}

export const ChatWindow = ({
  activeThread,
  onMessagesUpdate,
  onSidebarToggle,
  onClearChat,
  selectedModel,
  accessToken,
}: ChatWindowProps) => {
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const messages = activeThread?.messages || [];

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = async () => {
    if (!inputValue.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      content: inputValue.trim(),
      role: 'user',
      timestamp: new Date().toISOString(),
    };

    const newMessages = [...messages, userMessage];
    onMessagesUpdate(newMessages);
    setInputValue('');
    setIsLoading(true);

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-290939a6/chat`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accessToken || publicAnonKey}`,
          },
          body: JSON.stringify({
            message: userMessage.content,
            model: selectedModel,
          }),
        }
      );

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to get response');
      }

      const data = await response.json();

      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: data.response,
        role: 'bot',
        timestamp: data.timestamp,
      };

      onMessagesUpdate([...newMessages, botMessage]);
    } catch (error) {
      console.error('Error sending message:', error);
      
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: `Sorry, I encountered an error: ${error instanceof Error ? error.message : 'Unknown error'}. Please check that your OpenAI API key is configured correctly.`,
        role: 'bot',
        timestamp: new Date().toISOString(),
      };

      onMessagesUpdate([...newMessages, errorMessage]);
    } finally {
      setIsLoading(false);
      inputRef.current?.focus();
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="flex-1 flex flex-col h-screen">
      {/* Chat header */}
      <div className="sticky top-0 z-10 backdrop-blur-xl bg-white/5 border-b border-white/10 px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={onSidebarToggle}
              className="lg:hidden p-2 hover:bg-white/10 rounded-lg transition-colors"
              aria-label="Toggle sidebar"
            >
              <Menu className="w-5 h-5 text-white/70" />
            </button>
            <div>
              <h1 className="text-white/90">
                {activeThread?.title || 'New Conversation'}
              </h1>
              <p className="text-sm text-white/50">Powered by {selectedModel}</p>
            </div>
          </div>
          {messages.length > 0 && (
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={onClearChat}
              className="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-white/10 text-white/70 transition-colors"
            >
              <Trash2 className="w-4 h-4" />
              <span className="hidden sm:inline">Clear</span>
            </motion.button>
          )}
        </div>
      </div>

      {/* Messages area */}
      <div className="flex-1 overflow-y-auto px-4 py-6 space-y-6">
        {messages.length === 0 ? (
          <div className="h-full flex items-center justify-center">
            <div className="text-center max-w-md">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="mb-6"
              >
                <div className="w-20 h-20 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 flex items-center justify-center shadow-2xl shadow-indigo-500/50">
                  <Send className="w-10 h-10 text-white" />
                </div>
                <h2 className="text-white/90 mb-2">Start a Conversation</h2>
                <p className="text-white/50">
                  Send a message to begin chatting with your AI assistant
                </p>
              </motion.div>
              <div className="grid grid-cols-1 gap-3 text-left">
                {[
                  'Explain quantum computing',
                  'Write a creative story',
                  'Help me debug code',
                ].map((suggestion, i) => (
                  <motion.button
                    key={i}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.1 }}
                    whileHover={{ scale: 1.02 }}
                    onClick={() => setInputValue(suggestion)}
                    className="p-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-white/70 transition-all"
                  >
                    {suggestion}
                  </motion.button>
                ))}
              </div>
            </div>
          </div>
        ) : (
          <>
            {messages.map(message => (
              <MessageBubble key={message.id} message={message} />
            ))}
            {isLoading && (
              <div className="flex">
                <TypingIndicator />
              </div>
            )}
            <div ref={messagesEndRef} />
          </>
        )}
      </div>

      {/* Input area */}
      <div className="sticky bottom-0 backdrop-blur-xl bg-gradient-to-t from-slate-900/80 to-transparent border-t border-white/10 px-4 py-4">
        <div className="max-w-4xl mx-auto">
          <div className="relative flex items-end gap-2 bg-white/10 backdrop-blur-lg border border-white/20 rounded-2xl p-2">
            <textarea
              ref={inputRef}
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Type your message..."
              className="flex-1 bg-transparent text-white placeholder-white/40 resize-none outline-none px-3 py-2 max-h-32"
              rows={1}
              disabled={isLoading}
            />
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={handleSendMessage}
              disabled={!inputValue.trim() || isLoading}
              className="flex-shrink-0 w-10 h-10 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-500 flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed transition-all hover:shadow-lg hover:shadow-indigo-500/50"
              aria-label="Send message"
            >
              <Send className="w-5 h-5 text-white" />
            </motion.button>
          </div>
          <p className="text-xs text-white/30 text-center mt-2">
            Press Enter to send, Shift+Enter for new line
          </p>
        </div>
      </div>
    </div>
  );
};
