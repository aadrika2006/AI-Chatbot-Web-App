import { motion } from 'motion/react';
import { Moon, Sun, Settings, LogOut, Sparkles } from 'lucide-react';
import { UserProfile } from '../utils/storage';

interface NavbarProps {
  theme: 'light' | 'dark';
  onThemeToggle: () => void;
  userProfile: UserProfile | null;
  onSettingsClick: () => void;
  onLogout: () => void;
}

export const Navbar = ({ theme, onThemeToggle, userProfile, onSettingsClick, onLogout }: NavbarProps) => {
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <nav className="sticky top-0 z-50 backdrop-blur-xl bg-white/5 border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex items-center gap-3"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 flex items-center justify-center shadow-lg shadow-indigo-500/50">
              <Sparkles className="w-6 h-6 text-white" />
            </div>
            <span className="text-white/90">AI Chatbot</span>
          </motion.div>

          {/* Right section */}
          <div className="flex items-center gap-3">
            {/* Settings button */}
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={onSettingsClick}
              className="p-2 rounded-lg hover:bg-white/10 transition-colors"
              aria-label="Settings"
            >
              <Settings className="w-5 h-5 text-white/70" />
            </motion.button>

            {/* Theme toggle */}
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={onThemeToggle}
              className="p-2 rounded-lg hover:bg-white/10 transition-colors"
              aria-label="Toggle theme"
            >
              {theme === 'dark' ? (
                <Sun className="w-5 h-5 text-white/70" />
              ) : (
                <Moon className="w-5 h-5 text-white/70" />
              )}
            </motion.button>

            {/* Logout button */}
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={onLogout}
              className="p-2 rounded-lg hover:bg-white/10 transition-colors"
              aria-label="Logout"
            >
              <LogOut className="w-5 h-5 text-white/70" />
            </motion.button>

            {/* User avatar */}
            {userProfile && (
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                className="w-10 h-10 rounded-full bg-gradient-to-br from-emerald-400 to-cyan-400 flex items-center justify-center shadow-lg"
              >
                <span className="text-white text-sm">
                  {getInitials(userProfile.name)}
                </span>
              </motion.div>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};
