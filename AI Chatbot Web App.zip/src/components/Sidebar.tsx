import { motion, AnimatePresence } from 'motion/react';
import { MessageSquare, Plus, Trash2, X } from 'lucide-react';
import { ChatThread } from '../utils/storage';

interface SidebarProps {
  threads: ChatThread[];
  activeThreadId: string | null;
  onThreadSelect: (threadId: string) => void;
  onNewChat: () => void;
  onDeleteThread: (threadId: string) => void;
  isOpen: boolean;
  onClose: () => void;
}

export const Sidebar = ({
  threads,
  activeThreadId,
  onThreadSelect,
  onNewChat,
  onDeleteThread,
  isOpen,
  onClose,
}: SidebarProps) => {
  return (
    <>
      {/* Mobile overlay */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40 lg:hidden"
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <motion.aside
        initial={{ x: -300 }}
        animate={{ x: isOpen ? 0 : -300 }}
        className="fixed lg:sticky top-0 left-0 h-screen w-80 bg-white/5 backdrop-blur-xl border-r border-white/10 z-50 flex flex-col lg:translate-x-0"
      >
        {/* Header */}
        <div className="p-4 border-b border-white/10 flex items-center justify-between">
          <h2 className="text-white/90">Chat History</h2>
          <button
            onClick={onClose}
            className="lg:hidden p-2 hover:bg-white/10 rounded-lg transition-colors"
            aria-label="Close sidebar"
          >
            <X className="w-5 h-5 text-white/70" />
          </button>
        </div>

        {/* New chat button */}
        <div className="p-4">
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={onNewChat}
            className="w-full flex items-center gap-3 px-4 py-3 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-xl text-white transition-all hover:shadow-lg hover:shadow-indigo-500/50"
          >
            <Plus className="w-5 h-5" />
            <span>New Chat</span>
          </motion.button>
        </div>

        {/* Thread list */}
        <div className="flex-1 overflow-y-auto px-4 pb-4 space-y-2">
          {threads.length === 0 ? (
            <div className="text-center text-white/40 py-8">
              <MessageSquare className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p>No conversations yet</p>
              <p className="text-sm">Start a new chat to begin</p>
            </div>
          ) : (
            threads.map(thread => (
              <motion.div
                key={thread.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`group relative p-3 rounded-lg cursor-pointer transition-all ${
                  activeThreadId === thread.id
                    ? 'bg-white/10 border border-white/20'
                    : 'hover:bg-white/5'
                }`}
                onClick={() => onThreadSelect(thread.id)}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <p className="text-white/90 truncate">{thread.title}</p>
                    <p className="text-xs text-white/40 mt-1">
                      {new Date(thread.updatedAt).toLocaleDateString()}
                    </p>
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onDeleteThread(thread.id);
                    }}
                    className="opacity-0 group-hover:opacity-100 p-1 hover:bg-white/10 rounded transition-all"
                    aria-label="Delete thread"
                  >
                    <Trash2 className="w-4 h-4 text-red-400" />
                  </button>
                </div>
              </motion.div>
            ))
          )}
        </div>
      </motion.aside>
    </>
  );
};
