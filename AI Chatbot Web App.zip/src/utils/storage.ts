export interface Message {
  id: string;
  content: string;
  role: 'user' | 'bot';
  timestamp: string;
}

export interface ChatThread {
  id: string;
  title: string;
  messages: Message[];
  createdAt: string;
  updatedAt: string;
}

export interface UserProfile {
  name: string;
  email?: string;
  avatar?: string;
}

const STORAGE_KEYS = {
  CHAT_THREADS: 'chatbot_threads',
  ACTIVE_THREAD: 'chatbot_active_thread',
  USER_PROFILE: 'chatbot_user_profile',
  THEME: 'chatbot_theme',
  MODEL_PREFERENCE: 'chatbot_model',
};

export const storage = {
  // Chat threads
  getThreads: (): ChatThread[] => {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.CHAT_THREADS);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  saveThreads: (threads: ChatThread[]) => {
    localStorage.setItem(STORAGE_KEYS.CHAT_THREADS, JSON.stringify(threads));
  },

  addThread: (thread: ChatThread) => {
    const threads = storage.getThreads();
    threads.unshift(thread);
    storage.saveThreads(threads);
  },

  updateThread: (threadId: string, updates: Partial<ChatThread>) => {
    const threads = storage.getThreads();
    const index = threads.findIndex(t => t.id === threadId);
    if (index !== -1) {
      threads[index] = { ...threads[index], ...updates, updatedAt: new Date().toISOString() };
      storage.saveThreads(threads);
    }
  },

  deleteThread: (threadId: string) => {
    const threads = storage.getThreads().filter(t => t.id !== threadId);
    storage.saveThreads(threads);
  },

  // Active thread
  getActiveThreadId: (): string | null => {
    return localStorage.getItem(STORAGE_KEYS.ACTIVE_THREAD);
  },

  setActiveThreadId: (threadId: string) => {
    localStorage.setItem(STORAGE_KEYS.ACTIVE_THREAD, threadId);
  },

  // User profile
  getUserProfile: (): UserProfile | null => {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.USER_PROFILE);
      return data ? JSON.parse(data) : null;
    } catch {
      return null;
    }
  },

  saveUserProfile: (profile: UserProfile) => {
    localStorage.setItem(STORAGE_KEYS.USER_PROFILE, JSON.stringify(profile));
  },

  // Theme
  getTheme: (): 'light' | 'dark' => {
    return (localStorage.getItem(STORAGE_KEYS.THEME) as 'light' | 'dark') || 'dark';
  },

  setTheme: (theme: 'light' | 'dark') => {
    localStorage.setItem(STORAGE_KEYS.THEME, theme);
  },

  // Model preference
  getModelPreference: (): string => {
    return localStorage.getItem(STORAGE_KEYS.MODEL_PREFERENCE) || 'gpt-3.5-turbo';
  },

  setModelPreference: (model: string) => {
    localStorage.setItem(STORAGE_KEYS.MODEL_PREFERENCE, model);
  },

  // Clear all data
  clearAll: () => {
    Object.values(STORAGE_KEYS).forEach(key => {
      localStorage.removeItem(key);
    });
  },
};
