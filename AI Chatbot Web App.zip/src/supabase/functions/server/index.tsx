import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import { createClient } from "npm:@supabase/supabase-js@2";
import * as kv from "./kv_store.tsx";

const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-290939a6/health", (c) => {
  return c.json({ status: "ok" });
});

// Signup endpoint
app.post("/make-server-290939a6/signup", async (c) => {
  try {
    const { email, password, name } = await c.req.json();
    
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
    );
    
    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true
    });
    
    if (error) {
      console.log(`Signup error: ${error.message}`);
      return c.json({ error: error.message }, 400);
    }
    
    return c.json({ success: true, user: data.user });
  } catch (error) {
    console.log(`Signup exception: ${error}`);
    return c.json({ error: 'Signup failed' }, 500);
  }
});

// Chat endpoint with OpenAI integration
app.post("/make-server-290939a6/chat", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { message, model = 'gpt-3.5-turbo' } = await c.req.json();
    
    if (!message) {
      return c.json({ error: 'Message is required' }, 400);
    }
    
    // Get OpenAI API key from environment
    const openaiKey = Deno.env.get('OPENAI_API_KEY');
    if (!openaiKey) {
      console.log('OpenAI API key not configured');
      return c.json({ error: 'OpenAI API key not configured' }, 500);
    }
    
    // Optional: Verify user authentication
    let userId = 'guest';
    if (accessToken) {
      const supabase = createClient(
        Deno.env.get('SUPABASE_URL') ?? '',
        Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      );
      const { data: { user }, error } = await supabase.auth.getUser(accessToken);
      if (user?.id) {
        userId = user.id;
      }
    }
    
    // Call OpenAI API
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${openaiKey}`,
      },
      body: JSON.stringify({
        model,
        messages: [
          { role: 'system', content: 'You are a helpful AI assistant. Provide clear, concise, and friendly responses.' },
          { role: 'user', content: message }
        ],
        temperature: 0.7,
        max_tokens: 1000,
      }),
    });
    
    if (!response.ok) {
      const errorData = await response.text();
      console.log(`OpenAI API error (${response.status}): ${errorData}`);
      return c.json({ error: `OpenAI API error: ${response.status}` }, response.status);
    }
    
    const data = await response.json();
    const botResponse = data.choices[0]?.message?.content || 'Sorry, I could not generate a response.';
    
    // Optionally store chat history in KV store
    try {
      const chatKey = `chat_${userId}_${Date.now()}`;
      await kv.set(chatKey, JSON.stringify({
        user: message,
        bot: botResponse,
        timestamp: new Date().toISOString(),
        model,
      }));
    } catch (kvError) {
      console.log(`KV store error: ${kvError}`);
      // Don't fail the request if KV storage fails
    }
    
    return c.json({ 
      response: botResponse,
      model,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    console.log(`Chat endpoint error: ${error}`);
    return c.json({ error: 'Failed to process chat request' }, 500);
  }
});

// Get chat history endpoint
app.get("/make-server-290939a6/history", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    let userId = 'guest';
    if (accessToken) {
      const supabase = createClient(
        Deno.env.get('SUPABASE_URL') ?? '',
        Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      );
      const { data: { user }, error } = await supabase.auth.getUser(accessToken);
      if (user?.id) {
        userId = user.id;
      }
    }
    
    const history = await kv.getByPrefix(`chat_${userId}_`);
    const parsedHistory = history.map(item => JSON.parse(item));
    
    return c.json({ history: parsedHistory });
  } catch (error) {
    console.log(`History endpoint error: ${error}`);
    return c.json({ error: 'Failed to fetch history' }, 500);
  }
});

Deno.serve(app.fetch);