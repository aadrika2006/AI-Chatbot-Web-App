import { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { ChatWindow } from './components/ChatWindow';
import { SettingsModal } from './components/SettingsModal';
import { Login } from './pages/Login';
import { storage, ChatThread, Message, UserProfile } from './utils/storage';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [accessToken, setAccessToken] = useState<string>('');
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [theme, setTheme] = useState<'light' | 'dark'>('dark');
  const [threads, setThreads] = useState<ChatThread[]>([]);
  const [activeThreadId, setActiveThreadId] = useState<string | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [selectedModel, setSelectedModel] = useState('gpt-3.5-turbo');

  // Initialize app
  useEffect(() => {
    const savedProfile = storage.getUserProfile();
    const savedTheme = storage.getTheme();
    const savedModel = storage.getModelPreference();
    const savedThreads = storage.getThreads();
    const savedActiveThreadId = storage.getActiveThreadId();

    if (savedProfile) {
      setUserProfile(savedProfile);
      setIsLoggedIn(true);
    }

    setTheme(savedTheme);
    setSelectedModel(savedModel);
    setThreads(savedThreads);

    if (savedActiveThreadId && savedThreads.find(t => t.id === savedActiveThreadId)) {
      setActiveThreadId(savedActiveThreadId);
    } else if (savedThreads.length > 0) {
      setActiveThreadId(savedThreads[0].id);
      storage.setActiveThreadId(savedThreads[0].id);
    }
  }, []);

  // Apply theme
  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  const handleLogin = (token: string, profile: UserProfile) => {
    setAccessToken(token);
    setUserProfile(profile);
    setIsLoggedIn(true);
  };

  const handleLogout = () => {
    if (confirm('Are you sure you want to logout? Your chat history will be cleared.')) {
      storage.clearAll();
      setIsLoggedIn(false);
      setAccessToken('');
      setUserProfile(null);
      setThreads([]);
      setActiveThreadId(null);
    }
  };

  const handleThemeToggle = () => {
    const newTheme = theme === 'dark' ? 'light' : 'dark';
    setTheme(newTheme);
    storage.setTheme(newTheme);
  };

  const handleModelChange = (model: string) => {
    setSelectedModel(model);
    storage.setModelPreference(model);
    setIsSettingsOpen(false);
  };

  const handleNewChat = () => {
    const newThread: ChatThread = {
      id: Date.now().toString(),
      title: 'New Chat',
      messages: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    storage.addThread(newThread);
    setThreads([newThread, ...threads]);
    setActiveThreadId(newThread.id);
    storage.setActiveThreadId(newThread.id);
    setIsSidebarOpen(false);
  };

  const handleThreadSelect = (threadId: string) => {
    setActiveThreadId(threadId);
    storage.setActiveThreadId(threadId);
    setIsSidebarOpen(false);
  };

  const handleDeleteThread = (threadId: string) => {
    if (confirm('Delete this conversation?')) {
      storage.deleteThread(threadId);
      const updatedThreads = threads.filter(t => t.id !== threadId);
      setThreads(updatedThreads);

      if (activeThreadId === threadId) {
        if (updatedThreads.length > 0) {
          setActiveThreadId(updatedThreads[0].id);
          storage.setActiveThreadId(updatedThreads[0].id);
        } else {
          setActiveThreadId(null);
        }
      }
    }
  };

  const handleMessagesUpdate = (messages: Message[]) => {
    if (!activeThreadId) return;

    const thread = threads.find(t => t.id === activeThreadId);
    if (!thread) return;

    // Auto-generate title from first user message
    let title = thread.title;
    if (title === 'New Chat' && messages.length > 0) {
      const firstUserMessage = messages.find(m => m.role === 'user');
      if (firstUserMessage) {
        title = firstUserMessage.content.slice(0, 50) + (firstUserMessage.content.length > 50 ? '...' : '');
      }
    }

    const updatedThread = {
      ...thread,
      title,
      messages,
      updatedAt: new Date().toISOString(),
    };

    storage.updateThread(activeThreadId, updatedThread);
    setThreads(threads.map(t => (t.id === activeThreadId ? updatedThread : t)));
  };

  const handleClearChat = () => {
    if (!activeThreadId) return;
    if (confirm('Clear all messages in this chat?')) {
      handleMessagesUpdate([]);
    }
  };

  const activeThread = threads.find(t => t.id === activeThreadId) || null;

  if (!isLoggedIn) {
    return <Login onLogin={handleLogin} />;
  }

  return (
    <div className={`min-h-screen ${theme === 'dark' ? 'bg-gradient-to-br from-slate-900 via-indigo-900 to-emerald-800' : 'bg-gradient-to-br from-slate-100 via-indigo-100 to-emerald-100'}`}>
      <div className="flex flex-col h-screen">
        <Navbar
          theme={theme}
          onThemeToggle={handleThemeToggle}
          userProfile={userProfile}
          onSettingsClick={() => setIsSettingsOpen(true)}
          onLogout={handleLogout}
        />

        <div className="flex flex-1 overflow-hidden">
          <Sidebar
            threads={threads}
            activeThreadId={activeThreadId}
            onThreadSelect={handleThreadSelect}
            onNewChat={handleNewChat}
            onDeleteThread={handleDeleteThread}
            isOpen={isSidebarOpen}
            onClose={() => setIsSidebarOpen(false)}
          />

          <ChatWindow
            activeThread={activeThread}
            onMessagesUpdate={handleMessagesUpdate}
            onSidebarToggle={() => setIsSidebarOpen(!isSidebarOpen)}
            onClearChat={handleClearChat}
            selectedModel={selectedModel}
            accessToken={accessToken}
          />
        </div>
      </div>

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        selectedModel={selectedModel}
        onModelChange={handleModelChange}
      />
    </div>
  );
}

export default App;
